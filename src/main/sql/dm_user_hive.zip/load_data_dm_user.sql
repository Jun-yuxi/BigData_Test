-- load data to dm_user
insert into table qfbap_dm.dm_user_basic
partition(dt='20190709')
select 
a.user_id ,               
a.user_name ,                
a.user_gender   ,             
a.user_birthday   ,            
a.user_age   ,                   
a.constellation   ,            
a.province   ,                 
a.city   ,                     
a.city_level   ,              
a.e_mail   ,                   
a.op_mail   ,                  
a.mobile    ,                  
a.num_seg_mobile    ,             
a.op_Mobile   ,                
a.register_time   ,            
a.login_ip  ,                 
a.login_source  ,             
a.request_user   ,             
a.total_score  ,       
a.used_score   , 
'unKnown' ,
a.is_blacklist   ,            
a.is_married  ,              
a.education   ,                
a.monthly_income  ,     
a.profession  , 
b.is_pregnant_woman   ,
b.is_have_children   ,
b.is_have_car   ,
b.phone_brand  ,
b.phone_brand_level   ,
b.phone_cnt   ,
b.change_phone_cnt    ,
b.is_maja   ,
b.majia_account_cnt   ,
b.loyal_model  ,
b.shopping_type_model   ,
b.weight  ,
b.height    ,
current_timestamp() dw_date
 from (select *
            from qfbap_dwd.dwd_user) a
    left join (select *
                 from qfbap_dwd.dwd_user_extend ) b
      on (a.user_id = b.user_id)




